<?php
	mysql_connect('localhost','root','') or die("<h2>Koneksi Database Gagal..</h2>");
	mysql_select_db('stk') or die("<h2>Database Belum Ada..</h2>");
?>