<div class="container">
	<div class="navbar-inner" style="border:0px solid #bbb; border-radius:10px; padding:10px 20px 10px 20px; margin-top:45px; margin-left:auto; margin-right:auto;">
    	<div style="margin-top:2px; margin-bottom:2px; margin-left:auto; margin-right:auto;">
        	<a href="index.php">
            <table border="0" cellpadding="5" cellspacing="0" align="left">
                <tr>
					<td width="85%" align="left">
                    	<font face="Comic Sans MS, cursive" color="#FF0000"><h3>Sistem Pakar Diagnosa Penyakit Akibat Virus Eksantema</h3></font>
					</td>
				</tr>
			</table>
            </a>
		</div>
	</div>
    <div align="left" style="margin-top:2px; margin-bottom:2px; margin-left:28px;">
        <b><script src="lib/tanggal_masehi.js"></script></b>
    </div>
</div>