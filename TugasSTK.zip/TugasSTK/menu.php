


<div class="container">
	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
            <!-- Komponen navbar -->	
			<ul class="nav pull-left">
				<li class="active"><a href="./"><span class="icon-home"></span><b class="text-error"> Sistem Pakar</b></a></li>
				<li><a href="./"><span class="icon-home"></span><b> Home</b></a></li>
				<li><a href="informasi.php?hal=1"><span class="icon-info-sign"></span><b> Info Penyakit</b></a></li>
				<li><a href="./konsultasi/index.php"><span class="icon-book"></span><b> Konsultasi</b></a></li>	
			
			</ul>
			
		</div>
	</div>
</div>